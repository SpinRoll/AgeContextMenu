# Age Context Menu — versione portatile

Applicazione desktop WPF per Windows 11 x64. Il pacchetto finale è un singolo `AgeContextMenu.exe` autonomo: include il runtime .NET e incorpora il bridge Go basato sulla libreria ufficiale `filippo.io/age`.

> Stato: progetto sorgente in sviluppo. Non è ancora un binario Windows compilato o collaudato. Non usare con dati importanti finché non sono stati completati i test su Windows 11.

## Funzioni previste

- Voce HKCU `Cifra con age` per tutti i file.
- Voce HKCU `Decifra file .age` per i file `.age`.
- Cifratura age standard con passphrase Scrypt (`age-encryption.org/v1`).
- Richiesta Windows Hello tramite `UserConsentVerifierInterop` per app desktop con HWND.
- Passphrase nel Credential Manager dell'account Windows; non viene scritta in un file di testo o nel registro.
- Il bridge riceve la passphrase su stdin, non sulla command line né tramite variabile d'ambiente.
- Output temporaneo nella stessa directory e rename senza sovrascrittura.
- Il sorgente viene eliminato solo dopo che l'output è stato finalizzato e rinominato. Se la cancellazione sorgente fallisce, entrambe le copie rimangono.
- Nessuna finestra console durante l'uso normale.

## Importante: modello di sicurezza

Windows Hello e la passphrase age sono due cose distinte. `UserConsentVerifier` autentica l'utente prima che l'app legga la credenziale. Il Credential Manager protegge la credenziale nell'ambito dell'account Windows, ma questo non è un vincolo crittografico diretto alla chiave Windows Hello. Non affermiamo che la passphrase sia crittograficamente sbloccabile solo con Hello.

Per rispettare il limite di Generic Credential, l'interfaccia accetta passphrase da 12 a 1000 caratteri. La memoria gestita .NET e Go può contenere copie temporanee delle stringhe; i buffer espliciti vengono azzerati dove possibile, ma non si può garantire la cancellazione di ogni copia dalla RAM.

L'eliminazione di un file non equivale a una cancellazione sicura dei settori su SSD o unità con journaling. Il programma non sovrascrive la destinazione: se esiste già, interrompe l'operazione.

## Requisiti per chi COMPILA

Sul PC di sviluppo Windows:

- Windows 11 x64
- .NET 8 SDK
- Go 1.23 o successivo
- connessione internet durante il primo ripristino NuGet e il download del modulo Go `filippo.io/age`

**Chi usa il programma finito non deve installare .NET, Go, SDK o altri runtime.**

## Creare l'unico EXE portatile

1. Estrai il progetto su un PC Windows 11 x64.
2. Esegui `BUILD-WINDOWS.cmd`.
3. Attendi il ripristino delle dipendenze e la pubblicazione.
4. Il file finale sarà `Dist\AgeContextMenu.exe`.
5. Copia quel solo EXE nella cartella definitiva (ad esempio `Documenti\Age Context Menu`). Non spostarlo dopo aver registrato il menu contestuale: i comandi di Explorer puntano al percorso dell'EXE.

Il bridge age è incorporato come risorsa nell'EXE e, al primo utilizzo, viene estratto in `%LOCALAPPDATA%\AgeContextMenu\engine\agebridge.exe`. Questo file ausiliario è gestito automaticamente e non richiede installazione o privilegi amministrativi.

## Primo avvio

1. Avvia `AgeContextMenu.exe`.
2. Se Windows Hello non è configurato, premi **Apri impostazioni Windows Hello** e configura almeno un PIN Windows Hello. Biometria e PIN sono gestiti da Windows.
3. Crea una passphrase age robusta e confermala. Conservala anche in un password manager disponibile su iPhone: se la perdi, i file non sono recuperabili.
4. Premi **Installa menu contestuale**.
5. In Esplora file usa il tasto destro. In Windows 11, a seconda della versione e delle impostazioni, le voci classiche potrebbero apparire in **Mostra altre opzioni**.

## Uso

- `Cifra con age`: crea `nomefile.ext.age`.
- `Decifra file .age`: crea `nomefile.ext`.
- Prima dell'operazione viene chiesta conferma, poi Windows Hello.
- Se la destinazione esiste, l'operazione si interrompe senza sovrascriverla.
- Se la passphrase è errata o il file age è corrotto, il file `.age` sorgente resta intatto.

## Disinstallare il menu contestuale

Avvia `AgeContextMenu.exe` e premi **Rimuovi menu contestuale**. Per cancellare anche la credenziale salvata, esegui da un collegamento o da Esegui:

```text
"C:\percorso\AgeContextMenu.exe" --forget-credential
```

Attenzione: eliminando la credenziale locale, i file creati con quella passphrase saranno recuperabili solo se hai conservato la passphrase altrove.

## Compatibilità iPhone

Il file usa il formato age standard con recipient passphrase/Scrypt. Trasferiscilo su iPhone e usa un'app che supporti esplicitamente file age passphrase/Scrypt. La compatibilità specifica di Age Vault o AgePony va verificata con un file di prova prima di affidare documenti reali. Memorizza la stessa passphrase in un password manager o in Password di iCloud; Face ID protegge l'accesso al password manager, non modifica il formato age.

## Collaudo obbligatorio

Prima di usare file importanti, prova almeno:

1. file di testo piccolo, PDF, immagine, ZIP e file di grandi dimensioni;
2. decifratura con la passphrase corretta;
3. decifratura con passphrase errata;
4. file `.age` troncato/corrotto;
5. destinazione già esistente;
6. annullamento Windows Hello e Hello non configurato;
7. file aperto/bloccato da un'altra applicazione;
8. interruzione forzata durante cifratura e decifratura;
9. apertura su una seconda implementazione age e sull'app iOS scelta;
10. rimozione delle voci HKCU.
