@echo off
setlocal
cd /d "%~dp0AgeBridge"
where go >nul 2>nul || (echo ERRORE: Go 1.23 o successivo non trovato.& exit /b 1)
if not exist "..\AgeContextMenu\Assets" mkdir "..\AgeContextMenu\Assets"
set CGO_ENABLED=0
set GOOS=windows
set GOARCH=amd64
echo Download dipendenza ufficiale filippo.io/age e compilazione bridge...
go mod tidy
if errorlevel 1 exit /b 1
go build -trimpath -buildvcs=false -ldflags="-s -w" -o "..\AgeContextMenu\Assets\agebridge.exe" .
if errorlevel 1 exit /b 1
echo Bridge pronto.
