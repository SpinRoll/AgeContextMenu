@echo off
setlocal
cd /d "%~dp0"
call build-agebridge.cmd
if errorlevel 1 exit /b 1
where dotnet >nul 2>nul || (echo ERRORE: .NET 8 SDK non trovato sul PC usato per compilare.& exit /b 1)
echo Ripristino pacchetti NuGet e pubblicazione autonoma win-x64...
dotnet restore AgeContextMenu\AgeContextMenu.csproj
if errorlevel 1 exit /b 1
dotnet publish AgeContextMenu\AgeContextMenu.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o Dist
if errorlevel 1 exit /b 1
echo.
echo Pubblicazione completata: Dist\AgeContextMenu.exe
echo Copia il solo AgeContextMenu.exe sul PC Windows 11. Il bridge age e il runtime .NET sono incorporati.
pause
