using Windows.Security.Credentials.UI;

namespace AgeContextMenu.Services;

public sealed class WindowsHelloService
{
    public async Task<bool> IsAvailableAsync()
    {
        var result = await UserConsentVerifier.CheckAvailabilityAsync();
        return result == UserConsentVerifierAvailability.Available;
    }

    public async Task<bool> VerifyAsync(IntPtr ownerHwnd, string message)
    {
        if (ownerHwnd == IntPtr.Zero)
            throw new InvalidOperationException("Finestra di autenticazione non disponibile.");

        var availability = await UserConsentVerifier.CheckAvailabilityAsync();
        if (availability != UserConsentVerifierAvailability.Available)
            throw new InvalidOperationException(
                "Windows Hello non è disponibile. Configura un PIN o una biometria in Impostazioni > Account > Opzioni di accesso.");

        // Desktop WPF must use the HWND-aware interop API, not the UWP-only overload.
        var result = await UserConsentVerifierInterop.RequestVerificationForWindowAsync(ownerHwnd, message);
        return result == UserConsentVerificationResult.Verified;
    }
}
