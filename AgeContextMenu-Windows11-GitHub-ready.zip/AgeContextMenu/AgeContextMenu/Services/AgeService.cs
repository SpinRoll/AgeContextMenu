using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

namespace AgeContextMenu.Services;

public sealed class AgeService
{
    

    public async Task RunAsync(string operation, string input, string output, char[] passphrase, CancellationToken cancellationToken = default)
    {
        if (operation is not ("encrypt" or "decrypt")) throw new ArgumentOutOfRangeException(nameof(operation));
        string bridgePath = AgeBridgeLocator.GetPath();

        var start = new ProcessStartInfo
        {
            FileName = bridgePath,
            UseShellExecute = false,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden,
            RedirectStandardInput = true,
            RedirectStandardError = true,
            RedirectStandardOutput = true
        };
        start.ArgumentList.Add(operation);
        start.ArgumentList.Add(input);
        start.ArgumentList.Add(output);

        using var process = new Process { StartInfo = start };
        if (!process.Start()) throw new InvalidOperationException("Impossibile avviare il motore age.");

        Task<string> stderrTask = process.StandardError.ReadToEndAsync(cancellationToken);
        Task<string> stdoutTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        byte[] secret = Encoding.UTF8.GetBytes(passphrase);
        byte[] newline = { (byte)'\n' };
        try
        {
            await process.StandardInput.BaseStream.WriteAsync(secret, cancellationToken);
            await process.StandardInput.BaseStream.WriteAsync(newline, cancellationToken);
            await process.StandardInput.BaseStream.FlushAsync(cancellationToken);
            process.StandardInput.Close();
            await process.WaitForExitAsync(cancellationToken);
            string error = await stderrTask;
            _ = await stdoutTask;
            if (process.ExitCode != 0)
                throw new InvalidOperationException(string.IsNullOrWhiteSpace(error) ? "Il motore age ha restituito un errore." : error.Trim());
        }
        catch
        {
            try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
            throw;
        }
        finally
        {
            CryptographicOperations.ZeroMemory(secret);
            CryptographicOperations.ZeroMemory(newline);
        }
    }
}
