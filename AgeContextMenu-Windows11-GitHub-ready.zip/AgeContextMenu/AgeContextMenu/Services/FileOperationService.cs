namespace AgeContextMenu.Services;

/// <summary>
/// Performs streaming age operations into a same-directory temporary file.
/// The destination is committed with a non-overwriting rename; the source is deleted only
/// after the committed output exists. A failed operation leaves the source untouched.
/// </summary>
public sealed class FileOperationService
{
    private readonly AgeService _age = new();
    private readonly WindowsHelloService _hello = new();
    private readonly CredentialService _credentials = new();

    public async Task ExecuteAsync(string file, bool encrypt, IntPtr ownerHwnd,
        CancellationToken cancellationToken = default)
    {
        file = Path.GetFullPath(file);
        if (!File.Exists(file))
            throw new FileNotFoundException("File non trovato.", file);
        if (!encrypt && !file.EndsWith(".age", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("La decifratura è disponibile soltanto per file .age.");

        string destination = encrypt ? file + ".age" : file[..^4];
        if (string.IsNullOrWhiteSpace(Path.GetFileName(destination)))
            throw new InvalidOperationException("Nome del file di destinazione non valido.");
        if (File.Exists(destination) || Directory.Exists(destination))
            throw new IOException($"La destinazione esiste già: {destination}. Non verrà sovrascritta.");

        string directory = Path.GetDirectoryName(file)!;
        string temporary = Path.Combine(directory, $".agecontext-{Guid.NewGuid():N}.tmp");
        bool committed = false;
        char[]? password = null;

        try
        {
            bool verified = await _hello.VerifyAsync(ownerHwnd,
                encrypt ? "Autorizza la cifratura age" : "Autorizza la decifratura age");
            if (!verified)
                throw new OperationCanceledException("Autenticazione Windows Hello annullata.");

            password = _credentials.Read();

            // Keep the source open without write/delete sharing while age reads it.
            // This prevents another process from changing or replacing it mid-operation.
            using (new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read,
                       bufferSize: 1, options: FileOptions.SequentialScan))
            {
                await _age.RunAsync(encrypt ? "encrypt" : "decrypt", file,
                    temporary, password, cancellationToken);
            }

            if (!File.Exists(temporary))
                throw new IOException("Il motore age non ha creato il file temporaneo.");

            // Same directory means same volume. No overwrite: an existing destination is safe.
            File.Move(temporary, destination);
            committed = true;

            // Deletion is intentionally after commit. If it fails, both complete copies remain.
            File.Delete(file);
        }
        catch
        {
            if (!committed && File.Exists(temporary))
            {
                try { File.Delete(temporary); } catch { /* preserve original exception */ }
            }
            throw;
        }
        finally
        {
            if (password is not null)
                Array.Clear(password, 0, password.Length);
        }
    }
}
