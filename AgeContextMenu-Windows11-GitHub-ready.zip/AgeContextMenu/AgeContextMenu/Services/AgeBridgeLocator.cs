using System.Reflection;

namespace AgeContextMenu.Services;

/// <summary>
/// Extracts the embedded, self-contained age bridge to the current user's local app data.
/// The portable application remains a single EXE; no administrator rights are required.
/// </summary>
public static class AgeBridgeLocator
{
    private const string ResourceName = "AgeContextMenu.agebridge.exe";

    public static string GetPath()
    {
        string directory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "AgeContextMenu", "engine");
        Directory.CreateDirectory(directory);

        string destination = Path.Combine(directory, "agebridge.exe");
        using Stream resource = Assembly.GetExecutingAssembly()
            .GetManifestResourceStream(ResourceName)
            ?? throw new FileNotFoundException(
                "Il motore age non è incluso nell'eseguibile. Ricompila la versione portatile.");

        string temporary = destination + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            using (var output = new FileStream(temporary, FileMode.CreateNew,
                       FileAccess.Write, FileShare.None))
            {
                resource.CopyTo(output);
                output.Flush(flushToDisk: true);
            }

            // Replace atomically on the same volume. A stale engine is never partially overwritten.
            File.Move(temporary, destination, overwrite: true);
            return destination;
        }
        finally
        {
            if (File.Exists(temporary))
            {
                try { File.Delete(temporary); } catch { }
            }
        }
    }
}
