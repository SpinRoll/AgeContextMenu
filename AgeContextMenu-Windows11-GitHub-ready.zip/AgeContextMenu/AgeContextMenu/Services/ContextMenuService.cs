using Microsoft.Win32;

namespace AgeContextMenu.Services;

public sealed class ContextMenuService
{
    private const string EncryptKey = @"Software\Classes\*\shell\AgeEncrypt";
    private const string DecryptKey = @"Software\Classes\SystemFileAssociations\.age\shell\AgeDecrypt";

    public void Install()
    {
        string exe = Environment.ProcessPath
            ?? throw new InvalidOperationException("Percorso dell'eseguibile non disponibile.");
        if (!File.Exists(exe)) throw new FileNotFoundException("Eseguibile non trovato.", exe);
        CreateEntry(EncryptKey, "Cifra con age", exe, "--encrypt");
        CreateEntry(DecryptKey, "Decifra file .age", exe, "--decrypt");
    }

    private static void CreateEntry(string keyPath, string label, string exe, string verb)
    {
        using var key = Registry.CurrentUser.CreateSubKey(keyPath, writable: true)
            ?? throw new InvalidOperationException("Impossibile creare la chiave di registro.");
        key.SetValue("", label, RegistryValueKind.String);
        key.SetValue("Icon", exe, RegistryValueKind.String);
        using var command = key.CreateSubKey("command", writable: true)
            ?? throw new InvalidOperationException("Impossibile creare il comando di registro.");
        command.SetValue("", $"\"{exe}\" {verb} \"%1\"", RegistryValueKind.String);
    }

    public void Uninstall()
    {
        Registry.CurrentUser.DeleteSubKeyTree(EncryptKey, throwOnMissingSubKey: false);
        Registry.CurrentUser.DeleteSubKeyTree(DecryptKey, throwOnMissingSubKey: false);
    }
}
