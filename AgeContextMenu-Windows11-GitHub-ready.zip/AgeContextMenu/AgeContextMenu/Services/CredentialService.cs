using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace AgeContextMenu.Services;

/// <summary>
/// Stores a Generic Credential for the current Windows account.
/// Credential Manager provides account-scoped OS protection; Windows Hello is a separate
/// authorization gate in this app, not a cryptographic key binding for this credential.
/// </summary>
public sealed class CredentialService
{
    private const string Target = "AgeContextMenu.MasterPassphrase.v1";
    private const uint CredTypeGeneric = 1;
    private const uint CredPersistLocalMachine = 2;
    private const int ErrorNotFound = 1168;
    private const int MaximumBlobBytes = 2560; // documented Generic Credential blob limit

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct NativeCredential
    {
        public uint Flags;
        public uint Type;
        public string TargetName;
        public string? Comment;
        public System.Runtime.InteropServices.ComTypes.FILETIME LastWritten;
        public uint CredentialBlobSize;
        public IntPtr CredentialBlob;
        public uint Persist;
        public uint AttributeCount;
        public IntPtr Attributes;
        public string? TargetAlias;
        public string? UserName;
    }

    [DllImport("advapi32.dll", EntryPoint = "CredWriteW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredWrite(ref NativeCredential credential, uint flags);

    [DllImport("advapi32.dll", EntryPoint = "CredReadW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredRead(string target, uint type, uint flags, out IntPtr credential);

    [DllImport("advapi32.dll", EntryPoint = "CredDeleteW", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CredDelete(string target, uint type, uint flags);

    [DllImport("advapi32.dll", EntryPoint = "CredFree")]
    private static extern void CredFree(IntPtr buffer);

    public bool Exists()
    {
        if (!CredRead(Target, CredTypeGeneric, 0, out IntPtr ptr))
        {
            int error = Marshal.GetLastWin32Error();
            if (error == ErrorNotFound) return false;
            throw new Win32Exception(error);
        }
        CredFree(ptr);
        return true;
    }

    public void Save(string password)
    {
        byte[] blob = Encoding.Unicode.GetBytes(password);
        if (blob.Length == 0 || blob.Length > MaximumBlobBytes)
        {
            CryptographicOperations.ZeroMemory(blob);
            throw new ArgumentException("La passphrase supera il limite supportato dal Credential Manager.");
        }

        IntPtr unmanaged = IntPtr.Zero;
        try
        {
            unmanaged = Marshal.AllocHGlobal(blob.Length);
            Marshal.Copy(blob, 0, unmanaged, blob.Length);
            var credential = new NativeCredential
            {
                Type = CredTypeGeneric,
                TargetName = Target,
                CredentialBlob = unmanaged,
                CredentialBlobSize = checked((uint)blob.Length),
                Persist = CredPersistLocalMachine,
                UserName = Environment.UserName
            };
            if (!CredWrite(ref credential, 0))
                throw new Win32Exception(Marshal.GetLastWin32Error());
        }
        finally
        {
            CryptographicOperations.ZeroMemory(blob);
            if (unmanaged != IntPtr.Zero)
            {
                unsafe
                {
                    CryptographicOperations.ZeroMemory(
                        new Span<byte>((void*)unmanaged, blob.Length));
                }
                Marshal.FreeHGlobal(unmanaged);
            }
        }
    }

    public char[] Read()
    {
        if (!CredRead(Target, CredTypeGeneric, 0, out IntPtr ptr))
            throw new InvalidOperationException(
                "Passphrase non configurata. Avvia Age Context Menu per crearla.");

        try
        {
            var credential = Marshal.PtrToStructure<NativeCredential>(ptr);
            if (credential.CredentialBlob == IntPtr.Zero ||
                credential.CredentialBlobSize == 0 ||
                credential.CredentialBlobSize > MaximumBlobBytes ||
                credential.CredentialBlobSize % 2 != 0)
                throw new InvalidOperationException("La credenziale salvata non è valida.");

            int byteCount = checked((int)credential.CredentialBlobSize);
            byte[] bytes = new byte[byteCount];
            try
            {
                Marshal.Copy(credential.CredentialBlob, bytes, 0, byteCount);
                return Encoding.Unicode.GetChars(bytes);
            }
            finally { CryptographicOperations.ZeroMemory(bytes); }
        }
        finally { CredFree(ptr); }
    }

    public void Delete()
    {
        if (!CredDelete(Target, CredTypeGeneric, 0))
        {
            int error = Marshal.GetLastWin32Error();
            if (error != ErrorNotFound) throw new Win32Exception(error);
        }
    }
}
