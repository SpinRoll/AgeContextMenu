using System.Windows;
using AgeContextMenu.Services;

namespace AgeContextMenu;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try
        {
            if (e.Args.Length > 0 && e.Args[0] == "--install-context-menu")
            {
                new ContextMenuService().Install();
                Shutdown(0);
                return;
            }
            if (e.Args.Length > 0 && e.Args[0] == "--uninstall-context-menu")
            {
                new ContextMenuService().Uninstall();
                Shutdown(0);
                return;
            }
            if (e.Args.Length > 0 && e.Args[0] == "--forget-credential")
            {
                new CredentialService().Delete();
                Shutdown(0);
                return;
            }

            bool? encrypt = null;
            string? file = null;
            if (e.Args.Length >= 2 && (e.Args[0] == "--encrypt" || e.Args[0] == "--decrypt"))
            {
                encrypt = e.Args[0] == "--encrypt";
                file = e.Args[1];
            }

            var window = new MainWindow(file, encrypt);
            MainWindow = window;
            window.Show();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Age Context Menu", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
        }
    }
}
