using System.Windows;
using System.Windows.Interop;
using System.Diagnostics;
using AgeContextMenu.Services;

namespace AgeContextMenu;

public partial class MainWindow : Window
{
    private readonly CredentialService _credentials = new();
    private readonly WindowsHelloService _hello = new();
    private readonly string? _file;
    private readonly bool? _encrypt;
    private bool _busy;

    public MainWindow(string? file = null, bool? encrypt = null)
    {
        InitializeComponent();
        _file = file;
        _encrypt = encrypt;
        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (_file is not null)
        {
            ModeTitle.Text = _encrypt == true ? "Cifratura file" : "Decifratura file";
            FileLabel.Text = _file;
        }

        if (!_credentials.Exists())
        {
            PasswordPanel.Visibility = Visibility.Visible;
            StatusText.Text = "Prima di utilizzare il menu contestuale, crea una passphrase. Non potrà essere recuperata se la dimentichi.";
            if (_file is not null)
                StatusText.Text += " Dopo il salvataggio verrà richiesta la conferma dell'operazione.";
            return;
        }

        PasswordPanel.Visibility = Visibility.Collapsed;
        StatusText.Text = "Passphrase configurata.";
        if (_file is not null)
            await RunFileOperationAsync();
    }

    private async void SavePassword_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        string first = PasswordInput.Password;
        string second = ConfirmPasswordInput.Password;
        if (first.Length < 12 || first.Length > 1000)
        {
            MessageBox.Show("Usa una passphrase compresa tra 12 e 1000 caratteri.", "Age Context Menu", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (first.Contains('\r') || first.Contains('\n'))
        {
            MessageBox.Show("La passphrase non può contenere ritorni a capo.", "Age Context Menu", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!string.Equals(first, second, StringComparison.Ordinal))
        {
            MessageBox.Show("Le due passphrase non coincidono.", "Age Context Menu", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _busy = true;
        SaveButton.IsEnabled = false;
        try
        {
            if (!await _hello.IsAvailableAsync())
                throw new InvalidOperationException("Windows Hello non è configurato o non è disponibile. Apri Impostazioni > Account > Opzioni di accesso e configura PIN o biometria.");
            if (!await _hello.VerifyAsync(new WindowInteropHelper(this).Handle, "Conferma il salvataggio della passphrase age"))
                throw new OperationCanceledException("Verifica Windows Hello annullata.");

            _credentials.Save(first);
            PasswordInput.Clear();
            ConfirmPasswordInput.Clear();
            PasswordPanel.Visibility = Visibility.Collapsed;
            StatusText.Text = "Passphrase salvata nel Credential Manager di Windows (protezione dell'account Windows). Windows Hello resta un controllo di autorizzazione separato.";

            _busy = false;
            if (_file is not null)
                await RunFileOperationAsync();
            else
                MessageBox.Show("Configurazione completata.", "Age Context Menu", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Age Context Menu", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            _busy = false;
            SaveButton.IsEnabled = true;
        }
    }

    private async Task RunFileOperationAsync()
    {
        if (_file is null || _encrypt is null || _busy) return;
        string verb = _encrypt.Value ? "cifrare" : "decifrare";
        var answer = MessageBox.Show($"Vuoi {verb} questo file?\n\n{_file}\n\nIl file sorgente verrà eliminato soltanto dopo la creazione corretta del risultato.",
            "Age Context Menu", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (answer != MessageBoxResult.Yes) { Close(); return; }

        _busy = true;
        try
        {
            StatusText.Text = "Autenticazione e operazione in corso…";
            await new FileOperationService().ExecuteAsync(_file, _encrypt.Value, new WindowInteropHelper(this).Handle);
            MessageBox.Show(_encrypt.Value ? "File cifrato correttamente." : "File decifrato correttamente.",
                "Age Context Menu", MessageBoxButton.OK, MessageBoxImage.Information);
            Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Operazione non riuscita", MessageBoxButton.OK, MessageBoxImage.Error);
            StatusText.Text = "Operazione non completata. Il file sorgente è stato conservato.";
            _busy = false;
        }
    }

    private void ConfigureHello_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("ms-settings:signinoptions")
            {
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show("Apri Impostazioni > Account > Opzioni di accesso per configurare Windows Hello.\n\n" + ex.Message,
                "Windows Hello", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    private void Install_Click(object sender, RoutedEventArgs e)
    {
        try { new ContextMenuService().Install(); MessageBox.Show("Voci del menu contestuale installate per l'utente corrente."); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void Uninstall_Click(object sender, RoutedEventArgs e)
    {
        try { new ContextMenuService().Uninstall(); MessageBox.Show("Voci del menu contestuale rimosse. La passphrase salvata non è stata cancellata."); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Errore", MessageBoxButton.OK, MessageBoxImage.Error); }
    }
}
