module agebridge

go 1.23

require filippo.io/age v1.2.1
