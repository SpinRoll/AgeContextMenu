package main

import (
	"errors"
	"fmt"
	"io"
	"os"
	"strings"

	"filippo.io/age"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		os.Exit(1)
	}
}

func run() (retErr error) {
	if len(os.Args) != 4 {
		return errors.New("parametri del motore non validi")
	}
	operation, inputPath, outputPath := os.Args[1], os.Args[2], os.Args[3]
	if operation != "encrypt" && operation != "decrypt" {
		return errors.New("operazione non riconosciuta")
	}

	passphraseBytes, err := io.ReadAll(io.LimitReader(os.Stdin, 4097))
	if err != nil {
		return fmt.Errorf("lettura credenziale: %w", err)
	}
	defer wipe(passphraseBytes)
	if len(passphraseBytes) == 0 || len(passphraseBytes) > 4096 {
		return errors.New("passphrase vuota o troppo lunga")
	}
	passphrase := strings.TrimSuffix(string(passphraseBytes), "\n")
	passphrase = strings.TrimSuffix(passphrase, "\r")
	if passphrase == "" {
		return errors.New("passphrase vuota")
	}

	input, err := os.Open(inputPath)
	if err != nil {
		return fmt.Errorf("apertura file sorgente: %w", err)
	}
	defer input.Close()

	var recipient age.Recipient
	var identity age.Identity
	if operation == "encrypt" {
		r, err := age.NewScryptRecipient(passphrase)
		if err != nil {
			return fmt.Errorf("inizializzazione cifratura: %w", err)
		}
		r.SetWorkFactor(18)
		recipient = r
	} else {
		i, err := age.NewScryptIdentity(passphrase)
		if err != nil {
			return fmt.Errorf("inizializzazione decifratura: %w", err)
		}
		i.SetMaxWorkFactor(20)
		identity = i
	}

	// O_EXCL prevents replacing an existing path. The caller creates this file
	// in the source directory so the final rename stays on the same volume.
	output, err := os.OpenFile(outputPath, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return fmt.Errorf("creazione file temporaneo: %w", err)
	}
	defer func() {
		if closeErr := output.Close(); retErr == nil && closeErr != nil {
			retErr = closeErr
		}
		if retErr != nil {
			_ = os.Remove(outputPath)
		}
	}()

	if operation == "encrypt" {
		writer, err := age.Encrypt(output, recipient)
		if err != nil {
			return fmt.Errorf("inizializzazione file age: %w", err)
		}
		if _, err := io.Copy(writer, input); err != nil {
			_ = writer.Close()
			return fmt.Errorf("cifratura: %w", err)
		}
		if err := writer.Close(); err != nil {
			return fmt.Errorf("finalizzazione cifratura: %w", err)
		}
	} else {
		reader, err := age.Decrypt(input, identity)
		if err != nil {
			return fmt.Errorf("passphrase errata o file age non valido: %w", err)
		}
		if _, err := io.Copy(output, reader); err != nil {
			return fmt.Errorf("decifratura o verifica integrità: %w", err)
		}
	}

	if err := output.Sync(); err != nil {
		return fmt.Errorf("scrittura file temporaneo: %w", err)
	}
	return nil
}

func wipe(b []byte) {
	for i := range b {
		b[i] = 0
	}
}
